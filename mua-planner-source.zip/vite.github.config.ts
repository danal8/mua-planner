import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "node:path";

export default defineConfig({
  base: "/mua-planner/",
  plugins: [react()],
  resolve: { alias: { "@": path.resolve(__dirname, ".") } },
  build: { outDir: "gh-dist", emptyOutDir: true },
});
