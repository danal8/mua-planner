alter table public.clients alter column user_id drop not null;
alter table public.appointments alter column user_id drop not null;

grant select, insert, update, delete on table public.clients, public.appointments to anon;

create policy "clients_single_user_select" on public.clients for select to anon using (true);
create policy "clients_single_user_insert" on public.clients for insert to anon with check (user_id is null);
create policy "clients_single_user_update" on public.clients for update to anon using (user_id is null) with check (user_id is null);
create policy "clients_single_user_delete" on public.clients for delete to anon using (user_id is null);

create policy "appointments_single_user_select" on public.appointments for select to anon using (true);
create policy "appointments_single_user_insert" on public.appointments for insert to anon with check (user_id is null and exists (select 1 from public.clients c where c.id = client_id and c.user_id is null));
create policy "appointments_single_user_update" on public.appointments for update to anon using (user_id is null) with check (user_id is null and exists (select 1 from public.clients c where c.id = client_id and c.user_id is null));
create policy "appointments_single_user_delete" on public.appointments for delete to anon using (user_id is null);

create policy "client_photos_single_user_select" on storage.objects for select to anon using (bucket_id = 'client-photos' and (storage.foldername(name))[1] = 'single-user');
create policy "client_photos_single_user_insert" on storage.objects for insert to anon with check (bucket_id = 'client-photos' and (storage.foldername(name))[1] = 'single-user');
create policy "client_photos_single_user_update" on storage.objects for update to anon using (bucket_id = 'client-photos' and (storage.foldername(name))[1] = 'single-user') with check (bucket_id = 'client-photos' and (storage.foldername(name))[1] = 'single-user');
create policy "client_photos_single_user_delete" on storage.objects for delete to anon using (bucket_id = 'client-photos' and (storage.foldername(name))[1] = 'single-user');
