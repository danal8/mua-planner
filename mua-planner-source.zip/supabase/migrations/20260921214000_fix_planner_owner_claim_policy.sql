drop policy if exists "planner_owner_first_insert" on public.planner_ownership;
create policy "planner_owner_first_insert" on public.planner_ownership
for insert to authenticated
with check (id is true and (select auth.uid()) = user_id);