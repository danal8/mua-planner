create table public.clients (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(trim(name)) > 0),
  phone text not null,
  phone_normalized text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, phone_normalized)
);

create table public.appointments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  client_id uuid not null references public.clients(id) on delete cascade,
  appointment_date date not null,
  appointment_time time not null,
  duration_minutes integer not null default 90 check (duration_minutes between 15 and 720),
  category text not null check (category in ('Νυφικό', 'Βάπτιση', 'Βραδινό', 'Event', 'Άλλο')),
  amount_cents integer not null default 0 check (amount_cents >= 0),
  address text not null default '', floor text not null default '', bell text not null default '',
  notes text not null default '', photo_path text,
  status text not null default 'scheduled' check (status in ('scheduled', 'cancelled')),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);

create index appointments_user_date_time_idx on public.appointments (user_id, appointment_date, appointment_time);
create index appointments_client_id_idx on public.appointments (client_id);
alter table public.clients enable row level security;
alter table public.appointments enable row level security;
revoke all on table public.clients, public.appointments from anon;
grant select, insert, update, delete on table public.clients, public.appointments to authenticated;

create policy "clients_select_own" on public.clients for select to authenticated using ((select auth.uid()) = user_id);
create policy "clients_insert_own" on public.clients for insert to authenticated with check ((select auth.uid()) = user_id);
create policy "clients_update_own" on public.clients for update to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "clients_delete_own" on public.clients for delete to authenticated using ((select auth.uid()) = user_id);
create policy "appointments_select_own" on public.appointments for select to authenticated using ((select auth.uid()) = user_id);
create policy "appointments_insert_own" on public.appointments for insert to authenticated with check ((select auth.uid()) = user_id and exists (select 1 from public.clients c where c.id = client_id and c.user_id = (select auth.uid())));
create policy "appointments_update_own" on public.appointments for update to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id and exists (select 1 from public.clients c where c.id = client_id and c.user_id = (select auth.uid())));
create policy "appointments_delete_own" on public.appointments for delete to authenticated using ((select auth.uid()) = user_id);

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('client-photos', 'client-photos', false, 524288, array['image/jpeg', 'image/png', 'image/webp']);

create policy "client_photos_select_own" on storage.objects for select to authenticated using (bucket_id = 'client-photos' and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy "client_photos_insert_own" on storage.objects for insert to authenticated with check (bucket_id = 'client-photos' and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy "client_photos_update_own" on storage.objects for update to authenticated using (bucket_id = 'client-photos' and (storage.foldername(name))[1] = (select auth.uid())::text) with check (bucket_id = 'client-photos' and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy "client_photos_delete_own" on storage.objects for delete to authenticated using (bucket_id = 'client-photos' and (storage.foldername(name))[1] = (select auth.uid())::text);
