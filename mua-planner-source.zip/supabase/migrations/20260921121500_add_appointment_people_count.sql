alter table public.appointments
  add column people_count integer not null default 1
  check (people_count between 1 and 50);
