alter table public.appointments
  drop constraint if exists appointments_category_check;

alter table public.appointments
  add constraint appointments_category_check
  check (category in ('Νυφικό', 'Πρόβα νυφικού', 'Βάπτιση', 'Βραδινό', 'Event', 'Άλλο'));
