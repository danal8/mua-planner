drop policy if exists "clients_single_user_select" on public.clients;
drop policy if exists "clients_single_user_insert" on public.clients;
drop policy if exists "clients_single_user_update" on public.clients;
drop policy if exists "clients_single_user_delete" on public.clients;
drop policy if exists "appointments_single_user_select" on public.appointments;
drop policy if exists "appointments_single_user_insert" on public.appointments;
drop policy if exists "appointments_single_user_update" on public.appointments;
drop policy if exists "appointments_single_user_delete" on public.appointments;
drop policy if exists "client_photos_single_user_select" on storage.objects;
drop policy if exists "client_photos_single_user_insert" on storage.objects;
drop policy if exists "client_photos_single_user_update" on storage.objects;
drop policy if exists "client_photos_single_user_delete" on storage.objects;

revoke all on table public.clients, public.appointments from anon;
grant select, insert, update, delete on table public.clients, public.appointments to authenticated;

create table if not exists public.planner_ownership (
  id boolean primary key default true check (id),
  user_id uuid not null unique references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.planner_ownership enable row level security;
revoke all on table public.planner_ownership from anon;
grant select, insert on table public.planner_ownership to authenticated;

create policy "planner_owner_select" on public.planner_ownership
for select to authenticated using ((select auth.uid()) = user_id);
create policy "planner_owner_first_insert" on public.planner_ownership
for insert to authenticated with check (
  id is true and (select auth.uid()) = user_id
  and not exists (select 1 from public.planner_ownership)
);

create policy "clients_owner_claim_legacy" on public.clients
for update to authenticated
using (user_id is null and exists (select 1 from public.planner_ownership o where o.user_id = (select auth.uid())))
with check (user_id = (select auth.uid()));

create policy "appointments_owner_claim_legacy" on public.appointments
for update to authenticated
using (user_id is null and exists (select 1 from public.planner_ownership o where o.user_id = (select auth.uid())))
with check (user_id = (select auth.uid()));

create policy "client_photos_owner_legacy_select" on storage.objects
for select to authenticated using (
  bucket_id = 'client-photos' and (storage.foldername(name))[1] = 'single-user'
  and exists (select 1 from public.planner_ownership o where o.user_id = (select auth.uid()))
);
create policy "client_photos_owner_legacy_delete" on storage.objects
for delete to authenticated using (
  bucket_id = 'client-photos' and (storage.foldername(name))[1] = 'single-user'
  and exists (select 1 from public.planner_ownership o where o.user_id = (select auth.uid()))
);
