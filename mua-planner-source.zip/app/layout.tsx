import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "MUA Planner — Το πρόγραμμά σου",
  description: "Ραντεβού makeup, πελατολόγιο και πρόγραμμα σε ένα μέρος.",
  manifest: "/manifest.webmanifest",
  icons: {
    icon: [{ url: "/favicon-mua.svg", type: "image/svg+xml" }, { url: "/favicon-mua.png", type: "image/png" }],
    shortcut: "/favicon-mua.svg",
    apple: "/icon-mua-192.png",
  },
};
export default function RootLayout({children}: Readonly<{children: React.ReactNode}>) {
  return <html lang="el"><body>{children}</body></html>;
}
