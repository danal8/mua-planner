import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "MUA Planner — Το πρόγραμμά σου",
  description: "Ραντεβού makeup, πελατολόγιο και πρόγραμμα σε ένα μέρος.",
  icons: { icon: "/favicon.svg", shortcut: "/favicon.svg" },
};
export default function RootLayout({children}: Readonly<{children: React.ReactNode}>) {
  return <html lang="el"><body>{children}</body></html>;
}
