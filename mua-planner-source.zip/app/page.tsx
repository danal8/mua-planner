import Planner from '@/components/planner/Planner';
import AuthGate from '@/components/planner/AuthGate';
export default function Home() { return <AuthGate><Planner /></AuthGate>; }
