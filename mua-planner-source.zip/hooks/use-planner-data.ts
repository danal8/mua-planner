import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { repository } from "@/lib/planner/repository";
import { emptyData, type PlannerData } from "@/lib/planner/model";

export function usePlannerData() {
  const [data, setData] = useState<PlannerData>(emptyData);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  useEffect(() => {
    let disposed = false, running = false, pending = false, failures = 0;
    let timer: ReturnType<typeof setTimeout> | undefined;
    async function load() {
      if (disposed) return;
      if (running) { pending = true; return; }
      running = true;
      try {
        const next = await repository.load();
        if (!disposed) { setData(next); setLoadError(""); failures = 0; }
      } catch {
        if (!disposed) {
          setLoadError("Δεν ολοκληρώθηκε η φόρτωση. Η εφαρμογή θα δοκιμάσει ξανά αυτόματα μόλις επανέλθει η σύνδεση.");
          if (++failures <= 2) timer = setTimeout(() => void load(), failures * 2000);
        }
      } finally {
        running = false;
        if (!disposed) {
          setLoading(false);
          if (pending) { pending = false; schedule(); }
        }
      }
    }
    function schedule() {
      if (disposed || document.visibilityState === "hidden") return;
      clearTimeout(timer);
      // Leave Supabase's auth callback before making calls that acquire its session lock.
      timer = setTimeout(() => void load(), 0);
    }
    const { data: listener } = supabase.auth.onAuthStateChange((event, session) => {
      if (session && (event === "TOKEN_REFRESHED" || event === "SIGNED_IN")) schedule();
    });
    document.addEventListener("visibilitychange", schedule);
    window.addEventListener("focus", schedule);
    window.addEventListener("online", schedule);
    window.addEventListener("pageshow", schedule);
    void load();
    return () => {
      disposed = true; clearTimeout(timer); listener.subscription.unsubscribe();
      document.removeEventListener("visibilitychange", schedule);
      window.removeEventListener("focus", schedule);
      window.removeEventListener("online", schedule);
      window.removeEventListener("pageshow", schedule);
    };
  }, []);
  return { data, setData, loading, loadError };
}
