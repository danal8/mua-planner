import { emptyData, type Appointment, type Client, type PlannerRepository } from './model';
function connect(): Promise<IDBDatabase> {
  return new Promise((resolve,reject) => {
    const req = indexedDB.open('mua-planner',1);
    req.onupgradeneeded = () => { req.result.createObjectStore('clients',{keyPath:'id'}); req.result.createObjectStore('appointments',{keyPath:'id'}); };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
    req.onblocked = () => reject(new Error('Κλείσε τις άλλες καρτέλες της εφαρμογής και δοκίμασε ξανά.'));
  });
}
export class IndexedDBPlannerRepository implements PlannerRepository {
  async load() {
    const db = await connect();
    return new Promise<typeof emptyData>((resolve,reject) => {
      const tx = db.transaction(['clients','appointments'],'readonly');
      const clients = tx.objectStore('clients').getAll();
      const appointments = tx.objectStore('appointments').getAll();
      tx.oncomplete = () => { db.close(); resolve({version:1,clients:clients.result,appointments:appointments.result}); };
      tx.onerror = () => {db.close();reject(tx.error);};
      tx.onabort = () => {db.close();reject(tx.error);};
    });
  }
  async saveAppointment(appointment: Appointment, client: Client) {
    const db = await connect();
    return new Promise<void>((resolve,reject) => {
      const tx = db.transaction(['clients','appointments'],'readwrite');
      tx.objectStore('clients').put(client);
      tx.objectStore('appointments').put(appointment);
      tx.oncomplete = () => {db.close();resolve();};
      tx.onabort = () => {db.close();reject(tx.error);};
      tx.onerror = () => {db.close();reject(tx.error);};
    });
  }
}
export const repository: PlannerRepository = new IndexedDBPlannerRepository();
