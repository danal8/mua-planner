import { emptyData, type Appointment, type Client, type PlannerRepository } from "./model";
import { normalizedPhone } from "./domain";
import { supabase } from "@/lib/supabase";

type ClientRow = { id: string; name: string; phone: string; created_at: string };
type AppointmentRow = {
  id: string; client_id: string; appointment_date: string; appointment_time: string;
  duration_minutes: number; category: Appointment["category"]; amount_cents: number;
  address: string; floor: string; bell: string; notes: string; photo_path: string | null;
  status: Appointment["status"]; created_at: string; updated_at: string;
};

async function currentUserId() {
  const { data, error } = await supabase.auth.getUser();
  if (error || !data.user) throw new Error("Η σύνδεσή σου έληξε. Συνδέσου ξανά.");
  return data.user.id;
}

function dataUrlToBlob(dataUrl: string) {
  const [header, encoded] = dataUrl.split(",");
  const mime = header.match(/data:(.*?);/)?.[1] || "image/jpeg";
  const bytes = Uint8Array.from(atob(encoded), character => character.charCodeAt(0));
  return new Blob([bytes], { type: mime });
}

export class SupabasePlannerRepository implements PlannerRepository {
  async load() {
    const [{ data: clientRows, error: clientsError }, { data: appointmentRows, error: appointmentsError }] = await Promise.all([
      supabase.from("clients").select("id,name,phone,created_at").order("name"),
      supabase.from("appointments").select("id,client_id,appointment_date,appointment_time,duration_minutes,category,amount_cents,address,floor,bell,notes,photo_path,status,created_at,updated_at"),
    ]);
    if (clientsError) throw clientsError;
    if (appointmentsError) throw appointmentsError;

    const clients: Client[] = (clientRows as ClientRow[]).map(row => ({
      id: row.id, name: row.name, phone: row.phone, createdAt: row.created_at,
    }));
    const appointments = await Promise.all((appointmentRows as AppointmentRow[]).map(async row => {
      let photo: string | undefined;
      if (row.photo_path) {
        const { data } = await supabase.storage.from("client-photos").createSignedUrl(row.photo_path, 3600);
        photo = data?.signedUrl;
      }
      return {
        id: row.id, clientId: row.client_id, date: row.appointment_date,
        time: row.appointment_time.slice(0, 5), duration: row.duration_minutes,
        category: row.category, amountCents: row.amount_cents, address: row.address,
        floor: row.floor, bell: row.bell, notes: row.notes, photo,
        photoPath: row.photo_path || undefined, status: row.status,
        createdAt: row.created_at, updatedAt: row.updated_at,
      } satisfies Appointment;
    }));
    return { ...emptyData, clients, appointments };
  }

  async saveAppointment(appointment: Appointment, client: Client) {
    const userId = await currentUserId();
    const { error: clientError } = await supabase.from("clients").upsert({
      id: client.id, user_id: userId, name: client.name, phone: client.phone,
      phone_normalized: normalizedPhone(client.phone), created_at: client.createdAt,
      updated_at: new Date().toISOString(),
    });
    if (clientError) throw clientError;

    let photoPath = appointment.photoPath;
    if (appointment.photo?.startsWith("data:")) {
      photoPath = `${userId}/${appointment.id}.jpg`;
      const { error: photoError } = await supabase.storage
        .from("client-photos")
        .upload(photoPath, dataUrlToBlob(appointment.photo), { contentType: "image/jpeg", upsert: true });
      if (photoError) throw photoError;
    }

    const { error: appointmentError } = await supabase.from("appointments").upsert({
      id: appointment.id, user_id: userId, client_id: client.id,
      appointment_date: appointment.date, appointment_time: appointment.time,
      duration_minutes: appointment.duration, category: appointment.category,
      amount_cents: appointment.amountCents, address: appointment.address,
      floor: appointment.floor, bell: appointment.bell, notes: appointment.notes,
      photo_path: photoPath || null, status: appointment.status,
      created_at: appointment.createdAt, updated_at: appointment.updatedAt,
    });
    if (appointmentError) throw appointmentError;
  }
}

export const repository: PlannerRepository = new SupabasePlannerRepository();
