import { emptyData, type Appointment, type Client, type PlannerRepository } from "./model";
import { normalizedPhone } from "./domain";
import { supabase } from "@/lib/supabase";
import { ensurePlannerSession } from "./session";

type ClientRow = { id: string; name: string; phone: string; created_at: string };
type AppointmentRow = {
  id: string; client_id: string; appointment_date: string; appointment_time: string;
  duration_minutes: number; category: Appointment["category"]; people_count: number; amount_cents: number;
  address: string; floor: string; bell: string; notes: string; photo_path: string | null;
  status: Appointment["status"]; created_at: string; updated_at: string;
};

function dataUrlToBlob(dataUrl: string) {
  const [header, encoded] = dataUrl.split(",");
  const mime = header.match(/data:(.*?);/)?.[1] || "image/jpeg";
  const bytes = Uint8Array.from(atob(encoded), character => character.charCodeAt(0));
  return new Blob([bytes], { type: mime });
}

function imageExtension(mime: string) {
  if (mime === "image/png") return "png";
  if (mime === "image/webp") return "webp";
  return "jpg";
}

export class SupabasePlannerRepository implements PlannerRepository {
  async load() {
    await ensurePlannerSession();
    try { return await this.loadRows(); }
    catch (error) {
      const failure = error as { code?: string; status?: number };
      if (failure.code !== "PGRST301" && failure.code !== "PGRST303" && failure.status !== 401) throw error;
      await ensurePlannerSession(true);
      return await this.loadRows();
    }
  }

  private async loadRows() {
    const signal = AbortSignal.timeout(20000);
    const [{ data: clientRows, error: clientsError }, { data: appointmentRows, error: appointmentsError }] = await Promise.all([
      supabase.from("clients").select("id,name,phone,created_at").order("name").abortSignal(signal),
      supabase.from("appointments").select("id,client_id,appointment_date,appointment_time,duration_minutes,category,people_count,amount_cents,address,floor,bell,notes,photo_path,status,created_at,updated_at").abortSignal(signal),
    ]);
    if (clientsError) throw clientsError;
    if (appointmentsError) throw appointmentsError;

    const clients: Client[] = (clientRows as ClientRow[]).map(row => ({
      id: row.id, name: row.name, phone: row.phone, createdAt: row.created_at,
    }));
    const appointments = await Promise.all((appointmentRows as AppointmentRow[]).map(async row => {
      let photo: string | undefined;
      if (row.photo_path) {
        const { data } = await supabase.storage.from("client-photos").createSignedUrl(row.photo_path, 3600);
        photo = data?.signedUrl;
      }
      return {
        id: row.id, clientId: row.client_id, date: row.appointment_date,
        time: row.appointment_time.slice(0, 5), duration: row.duration_minutes,
        category: row.category, peopleCount: row.people_count, amountCents: row.amount_cents, address: row.address,
        floor: row.floor, bell: row.bell, notes: row.notes, photo,
        photoPath: row.photo_path || undefined, status: row.status,
        createdAt: row.created_at, updatedAt: row.updated_at,
      } satisfies Appointment;
    }));
    return { ...emptyData, clients, appointments };
  }

  async saveAppointment(appointment: Appointment, client: Client) {
    const session = await ensurePlannerSession();
    const { error: clientError } = await supabase.from("clients").upsert({
      id: client.id, user_id: session.user.id, name: client.name, phone: client.phone,
      phone_normalized: normalizedPhone(client.phone), created_at: client.createdAt,
      updated_at: new Date().toISOString(),
    });
    if (clientError) throw new Error(`Δεν αποθηκεύτηκαν τα στοιχεία πελάτισσας: ${clientError.message}`);

    let removedPhotoPath: string | undefined;
    if (!appointment.photo && !appointment.photoPath) {
      const { data: existingAppointment } = await supabase.from("appointments").select("photo_path").eq("id", appointment.id).maybeSingle();
      removedPhotoPath = existingAppointment?.photo_path || undefined;
    }

    let photoPath = appointment.photoPath;
    let replacedPhotoPath: string | undefined;
    if (appointment.photo?.startsWith("data:")) {
      const photoBlob = dataUrlToBlob(appointment.photo);
      const previousPhotoPath = photoPath;
      photoPath = `${session.user.id}/${appointment.id}-${crypto.randomUUID()}.${imageExtension(photoBlob.type)}`;
      const { error: photoError } = await supabase.storage
        .from("client-photos")
        .upload(photoPath, photoBlob, { contentType: photoBlob.type, upsert: true });
      if (photoError) throw new Error(`Δεν αποθηκεύτηκε η φωτογραφία: ${photoError.message}`);
      replacedPhotoPath = previousPhotoPath;
    }

    const { error: appointmentError } = await supabase.from("appointments").upsert({
      id: appointment.id, user_id: session.user.id, client_id: client.id,
      appointment_date: appointment.date, appointment_time: appointment.time,
      duration_minutes: appointment.duration, category: appointment.category, people_count: appointment.peopleCount,
      amount_cents: appointment.amountCents, address: appointment.address,
      floor: appointment.floor, bell: appointment.bell, notes: appointment.notes,
      photo_path: photoPath || null, status: appointment.status,
      created_at: appointment.createdAt, updated_at: appointment.updatedAt,
    });
    if (appointmentError) {
      if (photoPath && photoPath !== appointment.photoPath) {
        await supabase.storage.from("client-photos").remove([photoPath]);
      }
      throw new Error(`Δεν αποθηκεύτηκε το ραντεβού: ${appointmentError.message}`);
    }
    appointment.photoPath = photoPath;
    if (replacedPhotoPath) await supabase.storage.from("client-photos").remove([replacedPhotoPath]);
    if (removedPhotoPath) {
      const { error: removePhotoError } = await supabase.storage.from("client-photos").remove([removedPhotoPath]);
      if (removePhotoError) throw removePhotoError;
    }
  }

  async deleteAppointment(appointment: Appointment) {
    await ensurePlannerSession();
    const { error } = await supabase.from("appointments").delete().eq("id", appointment.id);
    if (error) throw error;
    if (appointment.photoPath) {
      const { error: photoError } = await supabase.storage.from("client-photos").remove([appointment.photoPath]);
      if (photoError) throw new Error(`Δεν αποθηκεύτηκε η φωτογραφία: ${photoError.message}`);
    }
  }

  async updateClient(client: Client) {
    await ensurePlannerSession();
    const { error } = await supabase.from("clients").update({
      name: client.name,
      phone: client.phone,
      phone_normalized: normalizedPhone(client.phone),
      updated_at: new Date().toISOString(),
    }).eq("id", client.id);
    if (error) throw error;
  }

  async deleteClient(client: Client, appointments: Appointment[]) {
    await ensurePlannerSession();
    const { error } = await supabase.from("clients").delete().eq("id", client.id);
    if (error) throw error;
    const photoPaths = appointments.flatMap(appointment => appointment.photoPath ? [appointment.photoPath] : []);
    if (photoPaths.length) {
      const { error: photoError } = await supabase.storage.from("client-photos").remove(photoPaths);
      if (photoError) throw new Error(`Δεν αποθηκεύτηκε η φωτογραφία: ${photoError.message}`);
    }
  }
}

export const repository: PlannerRepository = new SupabasePlannerRepository();
