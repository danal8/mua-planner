export const categories = ['Νυφικό', 'Βάπτιση', 'Βραδινό', 'Event', 'Άλλο'] as const;
export type Category = typeof categories[number];
export interface Client { id: string; name: string; phone: string; createdAt: string }
export interface Appointment {
  id: string; clientId: string; date: string; time: string; duration: number;
  category: Category; amountCents: number; address: string; floor: string;
  bell: string; notes: string; photo?: string; status: 'scheduled' | 'cancelled';
  createdAt: string; updatedAt: string;
}
export interface PlannerData { version: 1; clients: Client[]; appointments: Appointment[] }
export const emptyData: PlannerData = {version: 1, clients: [], appointments: []};
// Replace the device-local adapter with an authenticated Supabase adapter.
export interface PlannerRepository {
  load(): Promise<PlannerData>;
  saveAppointment(appointment: Appointment, client: Client): Promise<void>;
}
// Contract only. V1 never connects to Google.
export interface CalendarSyncAdapter {
  upsert(appointment: Appointment, client: Client): Promise<{externalEventId: string}>;
  cancel(externalEventId: string): Promise<void>;
}
export interface CalendarEventLink {
  appointmentId: string; provider: 'google'; externalEventId: string;
  calendarId: string; lastSyncedAt: string; localUpdatedAt: string;
}
