export const categories = ['Νυφικό', 'Βάπτιση', 'Βραδινό', 'Event', 'Άλλο'] as const;
export type Category = typeof categories[number];
export interface Client { id: string; name: string; phone: string; createdAt: string }
export interface Appointment {
  id: string; clientId: string; date: string; time: string; duration: number;
  category: Category; peopleCount: number; amountCents: number; address: string; floor: string;
  bell: string; notes: string; photo?: string; photoPath?: string; status: 'scheduled' | 'cancelled';
  createdAt: string; updatedAt: string;
}
export interface PlannerData { version: 1; clients: Client[]; appointments: Appointment[] }
export const emptyData: PlannerData = {version: 1, clients: [], appointments: []};
// Supabase-backed repository for the single-user planner.
export interface PlannerRepository {
  load(): Promise<PlannerData>;
  saveAppointment(appointment: Appointment, client: Client): Promise<void>;
  deleteAppointment(appointment: Appointment): Promise<void>;
  updateClient(client: Client): Promise<void>;
  deleteClient(client: Client, appointments: Appointment[]): Promise<void>;
}
// Contract only. V1 never connects to Google.
export interface CalendarSyncAdapter {
  upsert(appointment: Appointment, client: Client): Promise<{externalEventId: string}>;
  cancel(externalEventId: string): Promise<void>;
}
export interface CalendarEventLink {
  appointmentId: string; provider: 'google'; externalEventId: string;
  calendarId: string; lastSyncedAt: string; localUpdatedAt: string;
}
