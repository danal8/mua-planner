export async function compressPhoto(file: File): Promise<string> {
  if (!['image/jpeg','image/png','image/webp'].includes(file.type)) throw new Error('Επίλεξε φωτογραφία JPG, PNG ή WebP.');
  if(file.size > 20*1024*1024) throw new Error('Η αρχική φωτογραφία πρέπει να είναι έως 20 MB.');
  const bitmap = await createImageBitmap(file);
  try {
    const canvas = document.createElement('canvas');
    const outputType = file.type;
    let size = Math.min(1,1400/Math.max(bitmap.width,bitmap.height));
    for(let attempt=0;attempt<5;attempt++) {
      canvas.width=Math.max(1,Math.round(bitmap.width*size)); canvas.height=Math.max(1,Math.round(bitmap.height*size));
      const ctx = canvas.getContext('2d'); if(!ctx) throw new Error('Δεν ήταν δυνατή η επεξεργασία της φωτογραφίας.');
      ctx.clearRect(0,0,canvas.width,canvas.height);
      if(outputType==='image/jpeg') { ctx.fillStyle='#fff'; ctx.fillRect(0,0,canvas.width,canvas.height); }
      ctx.drawImage(bitmap,0,0,canvas.width,canvas.height);
      const quality=Math.max(0.5,0.82-attempt*0.08);
      const url=canvas.toDataURL(outputType,quality);
      if(url.length*0.75<=400*1024) return url;
      size*=0.78;
    }
    throw new Error('Η φωτογραφία είναι πολύ μεγάλη. Επίλεξε μια μικρότερη.');
  } finally { bitmap.close(); }
}
