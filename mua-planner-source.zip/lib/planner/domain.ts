import type { Appointment } from './model';
export function dateKey(date: Date) {
  return `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;
}
export const start = (a: Pick<Appointment, 'date' | 'time'>) => new Date(`${a.date}T${a.time}:00`).getTime();
export const end = (a: Pick<Appointment, 'date' | 'time' | 'duration'>) => start(a)+a.duration*60000;
export function status(a: Appointment, now = Date.now()) {
  return a.status === 'cancelled' ? 'cancelled' : end(a) <= now ? 'completed' : 'scheduled';
}
export const statusLabel = {cancelled:'Ακυρωμένο', completed:'Πραγματοποιήθηκε', scheduled:'Προγραμματισμένο'};
export function conflicts(a: Appointment, list: Appointment[]) {
  return a.status === 'cancelled' ? [] : list.filter(b => b.id !== a.id && b.status !== 'cancelled' && start(a) < end(b) && end(a) > start(b));
}
export function monthDays(month: Date) {
  const first = new Date(month.getFullYear(), month.getMonth(), 1);
  const offset = (first.getDay()+6)%7;
  const count = new Date(month.getFullYear(), month.getMonth()+1, 0).getDate();
  return Array.from({length: Math.ceil((offset+count)/7)*7}, (_,i) => new Date(first.getFullYear(), first.getMonth(), i-offset+1));
}
export const money = (cents: number) => new Intl.NumberFormat('el-GR', {style:'currency',currency:'EUR',maximumFractionDigits:2}).format(cents/100);
export const dayLabel = (date: string) => new Date(date+'T12:00:00').toLocaleDateString('el-GR', {weekday:'long',day:'numeric',month:'long'});
export const monthLabel = (month: Date) => month.toLocaleDateString('el-GR',{month:'long',year:'numeric'});
export const endLabel = (a: Appointment) => new Date(end(a)).toLocaleTimeString('el-GR',{hour:'2-digit',minute:'2-digit',hour12:false,hourCycle:'h23'});
export function normalizedPhone(phone: string) { return phone.replace(/\D/g,'').replace(/^0030|^30(?=\d{10}$)/,''); }
