import { supabase } from "@/lib/supabase";

let refreshing: ReturnType<typeof supabase.auth.refreshSession> | undefined;
export async function ensurePlannerSession(force = false) {
  const { data, error } = await supabase.auth.getSession();
  if (error) throw error;
  if (!data.session) throw new Error("Η σύνδεση έληξε. Συνδέσου ξανά.");
  if (force || (data.session.expires_at ?? 0) * 1000 <= Date.now() + 60000) {
    if (!refreshing) {
      refreshing = supabase.auth.refreshSession().finally(() => { refreshing = undefined; });
    }
    const result = await refreshing;
    if (result.error) throw result.error;
    if (!result.data.session) throw new Error("Η σύνδεση έληξε. Συνδέσου ξανά.");
  }
}
