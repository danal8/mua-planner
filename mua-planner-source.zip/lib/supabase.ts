import { createClient } from "@supabase/supabase-js";

const supabaseUrl = "https://htlifrjwigbeqijsqzxn.supabase.co";
const supabasePublishableKey = "sb_publishable_gHcyF5k8vii7E8iZdO1fHg_a32hkByH";

export const supabase = createClient(supabaseUrl, supabasePublishableKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});
