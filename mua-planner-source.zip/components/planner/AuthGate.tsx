"use client";

import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import type { Session } from "@supabase/supabase-js";
import { supabase } from "@/lib/supabase";

export default function AuthGate({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null | undefined>(undefined);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    void supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data } = supabase.auth.onAuthStateChange((_event, nextSession) => setSession(nextSession));
    return () => data.subscription.unsubscribe();
  }, []);

  async function login(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError("");
    const { error: loginError } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    if (loginError) setError("Λάθος email ή κωδικός πρόσβασης.");
    setBusy(false);
  }

  if (session === undefined) return <div className="loading">Έλεγχος σύνδεσης…</div>;
  if (!session) return <main className="auth-page"><section className="auth-card"><div className="auth-logo">MUA</div><h1>MUA Planner</h1><p>Συνδέσου για να δεις το πρόγραμμά σου.</p><form onSubmit={login}><label className="field">Email<input type="email" autoComplete="email" required value={email} onChange={event=>setEmail(event.target.value)}/></label><label className="field">Κωδικός<input type="password" autoComplete="current-password" required value={password} onChange={event=>setPassword(event.target.value)}/></label>{error&&<div className="notice error" role="alert">{error}</div>}<button className="primary auth-submit" disabled={busy}>{busy?"Σύνδεση…":"Σύνδεση"}</button></form></section></main>;
  return <>{children}</>;
}
