"use client";

import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import {
  CalendarDays, ChevronLeft, ChevronRight, CirclePlus, Cloud, Edit3,
  MapPin, Search, Sparkles, Users, X, BarChart3, CalendarPlus, UserRound
} from "lucide-react";
import { categories, emptyData, type Appointment, type Client, type PlannerData } from "@/lib/planner/model";
import { conflicts, dateKey, dayLabel, endLabel, money, monthDays, monthLabel, normalizedPhone, start, status, statusLabel } from "@/lib/planner/domain";
import { repository } from "@/lib/planner/repository";
import { compressPhoto } from "@/lib/planner/photo";

type View = "calendar" | "clients" | "stats";
type Draft = Omit<Appointment, "id" | "clientId" | "amountCents" | "createdAt" | "updatedAt"> & {
  id?: string; clientId?: string; name: string; phone: string; amount: string;
};

const today = dateKey(new Date());
const blankDraft = (date = today): Draft => ({
  date, time: "10:00", duration: 90, name: "", phone: "", category: "Νυφικό",
  amount: "", address: "", floor: "", bell: "", notes: "", photo: undefined, status: "scheduled"
});

function Brand() {
  return <div className="brand"><span className="monogram">m</span><span><strong>MUA Planner</strong><small>BEAUTY AGENDA</small></span></div>;
}

export default function Planner() {
  return <PlannerWorkspace/>;
}

function Navigation({view, setView}: {view: View; setView: (view: View) => void}) {
  const items: Array<[View, string, typeof CalendarDays]> = [
    ["calendar", "Πρόγραμμα", CalendarDays], ["clients", "Πελάτισσες", Users], ["stats", "Στατιστικά", BarChart3]
  ];
  return <>{items.map(([key,label,Icon]) => <button key={key} className={view===key?"active":""} onClick={()=>setView(key)}><Icon />{label}</button>)}</>;
}

function AppointmentRow({appointment, client, edit}: {appointment: Appointment; client?: Client; edit: () => void}) {
  const appointmentStatus = status(appointment);
  return <article className={`appointment ${appointmentStatus}`}>
    <div className="appointment-time">{appointment.time}<small>{endLabel(appointment)}</small></div>
    <div className="appointment-info">
      <span className="badge" data-category={appointment.category}>{appointment.category}</span>
      <strong>{client?.name || "Χωρίς όνομα"}</strong>
      {appointment.address && <a className="address-link" href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(appointment.address)}`} target="_blank" rel="noreferrer"><MapPin />{appointment.address}</a>}
      <span className="status-text">{statusLabel[appointmentStatus]} · {money(appointment.amountCents)}</span>
    </div>
    <button className="edit-button" onClick={edit} aria-label={`Επεξεργασία ραντεβού ${client?.name || ""}`}><Edit3 /></button>
  </article>;
}

function AppointmentModal({draft, all, clients, onClose, onSaved}: {
  draft: Draft; all: Appointment[]; clients: Client[]; onClose: () => void;
  onSaved: (appointment: Appointment, client: Client) => Promise<void>;
}) {
  const [form, setForm] = useState(draft);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [photoBusy, setPhotoBusy] = useState(false);
  const dialog = useRef<HTMLDivElement>(null);
  const candidate: Appointment = {
    id: form.id || "new", clientId: form.clientId || "new", date: form.date, time: form.time,
    duration: Number(form.duration), category: form.category, amountCents: Math.round((Number(form.amount.replace(",","."))||0)*100),
    address: form.address, floor: form.floor, bell: form.bell, notes: form.notes, photo: form.photo,
    status: form.status, createdAt: "", updatedAt: ""
  };
  const overlaps = conflicts(candidate, all);
  useEffect(() => {
    dialog.current?.focus();
    const handler = (event: KeyboardEvent) => { if(event.key === "Escape") onClose(); };
    document.addEventListener("keydown", handler); document.body.style.overflow="hidden";
    return () => { document.removeEventListener("keydown", handler); document.body.style.overflow=""; };
  }, [onClose]);
  const change = <K extends keyof Draft>(key: K, value: Draft[K]) => setForm(current => ({...current,[key]:value}));
  async function submit(event: FormEvent) {
    event.preventDefault(); setError("");
    if(!form.name.trim() || !form.phone.trim() || !form.date || !form.time) { setError("Συμπλήρωσε όνομα, τηλέφωνο, ημερομηνία και ώρα."); return; }
    if(Number(form.duration) < 15 || Number(form.duration) > 720) { setError("Η διάρκεια πρέπει να είναι από 15 έως 720 λεπτά."); return; }
    setSaving(true);
    try {
      const now = new Date().toISOString();
      const phoneKey = normalizedPhone(form.phone);
      const existingClient = clients.find(c => c.id === form.clientId) || clients.find(c => normalizedPhone(c.phone) === phoneKey);
      const client: Client = {id: existingClient?.id || crypto.randomUUID(), name: form.name.trim(), phone: form.phone.trim(), createdAt: existingClient?.createdAt || now};
      await onSaved({...candidate,id:form.id || crypto.randomUUID(),clientId:client.id,createdAt:all.find(a=>a.id===form.id)?.createdAt || now,updatedAt:now},client);
    } catch (reason) { setError(reason instanceof Error ? reason.message : "Δεν αποθηκεύτηκε το ραντεβού."); setSaving(false); }
  }
  return <><div className="modal-overlay" onMouseDown={onClose}/><div className="modal" role="dialog" aria-modal="true" aria-labelledby="appointment-title" tabIndex={-1} ref={dialog}>
    <div className="modal-heading"><h2 id="appointment-title">{form.id?"Επεξεργασία ραντεβού":"Νέο ραντεβού"}</h2><button className="icon-button" onClick={onClose} aria-label="Κλείσιμο"><X /></button></div>
    <p className="modal-description">Τα στοιχεία αποθηκεύονται αυτόματα στο cloud.</p>
    <form onSubmit={submit}>
      <div className="form-grid">
        <label className="field full">Όνομα πελάτισσας<input autoFocus required value={form.name} onChange={e=>change("name",e.target.value)} autoComplete="name" /></label>
        <label className="field full">Τηλέφωνο<input required inputMode="tel" value={form.phone} onChange={e=>change("phone",e.target.value)} autoComplete="tel" /></label>
        <div className="form-section">Ημερομηνία & υπηρεσία</div>
        <label className="field">Ημερομηνία<input required type="date" value={form.date} onChange={e=>change("date",e.target.value)} /></label>
        <label className="field">Ώρα<input required type="time" value={form.time} onChange={e=>change("time",e.target.value)} /></label>
        <label className="field">Διάρκεια<select value={form.duration} onChange={e=>change("duration",Number(e.target.value))}>{[30,45,60,90,120,150,180,240].map(value=><option key={value} value={value}>{value<60?`${value} λεπτά`:`${value/60} ώρ${value===60?"α":"ες"}`}</option>)}</select></label>
        <label className="field">Κατηγορία<select value={form.category} onChange={e=>change("category",e.target.value as Draft["category"])}>{categories.map(value=><option key={value}>{value}</option>)}</select></label>
        <label className="field">Ποσό (€)<input type="number" inputMode="decimal" min="0" step="0.01" value={form.amount} onChange={e=>change("amount",e.target.value)} placeholder="0,00" /></label>
        <label className="field">Κατάσταση<select value={form.status} onChange={e=>change("status",e.target.value as Draft["status"])}><option value="scheduled">Προγραμματισμένο</option><option value="cancelled">Ακυρωμένο</option></select></label>
        {overlaps.length>0 && <div className="field full notice">Υπάρχει χρονική επικάλυψη με {overlaps.length} άλλο ραντεβού. Μπορείς να συνεχίσεις αν είναι σκόπιμο.</div>}
        <div className="form-section">Τοποθεσία & λεπτομέρειες</div>
        <label className="field full">Διεύθυνση<input value={form.address} onChange={e=>change("address",e.target.value)} placeholder="Οδός, αριθμός, περιοχή" autoComplete="street-address" /></label>
        <label className="field">Όροφος<input value={form.floor} onChange={e=>change("floor",e.target.value)} placeholder="π.χ. 2ος" /></label>
        <label className="field">Κουδούνι<input value={form.bell} onChange={e=>change("bell",e.target.value)} /></label>
        <label className="field full">Σημειώσεις<textarea value={form.notes} onChange={e=>change("notes",e.target.value)} placeholder="Look, προτιμήσεις, parking…" /></label>
        <label className="field full upload">Προαιρετική φωτογραφία (συμπιέζεται αυτόματα)
          <input type="file" accept="image/jpeg,image/png,image/webp" disabled={photoBusy} onChange={async e=>{const file=e.target.files?.[0];if(!file)return;setPhotoBusy(true);setError("");try{change("photo",await compressPhoto(file));}catch(reason){setError(reason instanceof Error?reason.message:"Δεν φορτώθηκε η φωτογραφία.");}finally{setPhotoBusy(false);}}}/>
          {photoBusy && <span> Επεξεργασία…</span>}{form.photo && <img className="photo-preview" src={form.photo} alt="Προεπισκόπηση" />}
        </label>
      </div>
      {error && <div className="notice error" role="alert">{error}</div>}
      <div className="form-actions"><button type="button" className="secondary" onClick={onClose}>Ακύρωση</button><button className="primary" disabled={saving||photoBusy}>{saving?"Αποθήκευση…":"Αποθήκευση"}</button></div>
    </form>
  </div></>;
}

function PlannerWorkspace() {
  const [data,setData]=useState<PlannerData>(emptyData);
  const [loading,setLoading]=useState(true);
  const [loadError,setLoadError]=useState("");
  const [view,setView]=useState<View>("calendar");
  const [selected,setSelected]=useState(today);
  const [month,setMonth]=useState(()=>new Date(new Date().getFullYear(),new Date().getMonth(),1));
  const [editing,setEditing]=useState<Draft|null>(null);
  const [historyClient,setHistoryClient]=useState<Client|null>(null);
  const [search,setSearch]=useState("");
  const [toast,setToast]=useState("");
  useEffect(()=>{repository.load().then(setData).catch(reason=>setLoadError(reason instanceof Error?reason.message:"Δεν φορτώθηκαν τα δεδομένα.")).finally(()=>setLoading(false));},[]);
  useEffect(()=>{if(!toast)return;const id=setTimeout(()=>setToast(""),2600);return()=>clearTimeout(id);},[toast]);
  const clientsById=useMemo(()=>new Map(data.clients.map(c=>[c.id,c])),[data.clients]);
  const byDate=(date:string)=>data.appointments.filter(a=>a.date===date).sort((a,b)=>start(a)-start(b));
  const selectedAppointments=byDate(selected);
  const upcoming=useMemo(()=>data.appointments.filter(a=>status(a)==="scheduled").sort((a,b)=>start(a)-start(b)),[data.appointments]);
  const upcomingGroups=useMemo(()=>Object.entries(Object.groupBy(upcoming.slice(0,8),a=>a.date)),[upcoming]);
  const openNew=(date=selected)=>setEditing(blankDraft(date));
  const edit=(a:Appointment)=>{const c=clientsById.get(a.clientId);setEditing({...a,name:c?.name||"",phone:c?.phone||"",amount:String(a.amountCents/100)});};
  async function saved(appointment:Appointment,client:Client){await repository.saveAppointment(appointment,client);setData(current=>({version:1,clients:[...current.clients.filter(c=>c.id!==client.id),client],appointments:[...current.appointments.filter(a=>a.id!==appointment.id),appointment]}));setEditing(null);setToast("Το ραντεβού αποθηκεύτηκε");setSelected(appointment.date);setMonth(new Date(appointment.date+"T12:00:00"));setView("calendar");}
  function selectDate(date:Date){const key=dateKey(date);setSelected(key);if(date.getMonth()!==month.getMonth())setMonth(new Date(date.getFullYear(),date.getMonth(),1));}
  const heading = view==="calendar"?["Το πρόγραμμά σου","Δες τη διαθεσιμότητα και κλείσε γρήγορα το επόμενο ραντεβού."]:view==="clients"?["Πελατολόγιο","Κάθε πελάτισσα και το ιστορικό των ραντεβού της."]:["Στατιστικά","Μια καθαρή εικόνα της δουλειάς σου."];
  if(loading)return <main className="loading">Φόρτωση προγράμματος…</main>;
  return <div className="app">
    <aside className="sidebar"><Brand/><nav className="nav" aria-label="Κύρια πλοήγηση"><Navigation view={view} setView={setView}/></nav><div className="sidebar-note"><Cloud/><strong>Αποθήκευση στο cloud</strong><br/>Τα δεδομένα συγχρονίζονται αυτόματα.</div></aside>
    <main className="workspace">
      <header className="topbar"><Brand/><span className="desktop-date">{new Date().toLocaleDateString("el-GR",{weekday:"long",day:"numeric",month:"long"})}</span><span className="local-chip"><Cloud/> Cloud</span></header>
      <section className="heading"><div><h1>{heading[0]}</h1><p>{heading[1]}</p></div><button className="primary" onClick={()=>openNew()}><CirclePlus/> Νέο Ραντεβού</button></section>
      {loadError && <div className="notice error">{loadError}</div>}
      {view==="calendar" && <CalendarView month={month} selected={selected} appointments={data.appointments} clientsById={clientsById} selectedAppointments={selectedAppointments} upcomingGroups={upcomingGroups} onMonth={setMonth} onSelect={selectDate} onNew={openNew} onEdit={edit}/>} 
      {view==="clients" && <ClientsView clients={data.clients} appointments={data.appointments} search={search} setSearch={setSearch} onHistory={setHistoryClient}/>} 
      {view==="stats" && <StatsView data={data}/>} 
    </main>
    <nav className="bottom-nav" aria-label="Κύρια πλοήγηση"><Navigation view={view} setView={setView}/></nav>
    {editing && <AppointmentModal draft={editing} all={data.appointments} clients={data.clients} onClose={()=>setEditing(null)} onSaved={saved}/>} 
    {historyClient && <HistoryModal client={historyClient} appointments={data.appointments.filter(a=>a.clientId===historyClient.id)} onClose={()=>setHistoryClient(null)} onEdit={a=>{setHistoryClient(null);edit(a);}}/>}
    {toast && <div className="toast" role="status">{toast}</div>}
  </div>;
}

function CalendarView({month,selected,appointments,clientsById,selectedAppointments,upcomingGroups,onMonth,onSelect,onNew,onEdit}:{month:Date;selected:string;appointments:Appointment[];clientsById:Map<string,Client>;selectedAppointments:Appointment[];upcomingGroups:Array<[string,Appointment[]|undefined]>;onMonth:(date:Date)=>void;onSelect:(date:Date)=>void;onNew:(date?:string)=>void;onEdit:(a:Appointment)=>void}) {
  const days=monthDays(month);
  return <><div className="calendar-layout">
    <section className="card calendar" aria-label="Μηνιαίο ημερολόγιο"><div className="calendar-header"><h2>{monthLabel(month)}</h2><div className="calendar-arrows"><button className="icon-button" aria-label="Προηγούμενος μήνας" onClick={()=>onMonth(new Date(month.getFullYear(),month.getMonth()-1,1))}><ChevronLeft/></button><button className="icon-button" aria-label="Επόμενος μήνας" onClick={()=>onMonth(new Date(month.getFullYear(),month.getMonth()+1,1))}><ChevronRight/></button></div></div>
      <div className="weekdays">{["ΔΕΥ","ΤΡΙ","ΤΕΤ","ΠΕΜ","ΠΑΡ","ΣΑΒ","ΚΥΡ"].map((d,i)=><span className={i>4?"weekend":""} key={d}>{d}</span>)}</div>
      <div className="days">{days.map(date=>{const key=dateKey(date);const count=appointments.filter(a=>a.date===key&&a.status!=="cancelled").length;return <button key={key} className={`day ${date.getMonth()!==month.getMonth()?"outside ":""}${date.getDay()===0||date.getDay()===6?"weekend ":""}${key===today?"today ":""}${key===selected?"selected":""}`} onClick={()=>onSelect(date)} aria-label={`${date.toLocaleDateString("el-GR")}, ${count} ραντεβού`}><span>{date.getDate()}</span>{count?<span className="count">{count}</span>:<span className="empty-count"/>}</button>})}</div>
      <div className="legend"><span><i/> Σήμερα</span><span>Ο αριθμός δείχνει τα ραντεβού</span></div>
    </section>
    <section className="card day-panel"><div className="panel-heading"><span className="eyebrow">ΕΠΙΛΕΓΜΕΝΗ ΗΜΕΡΑ</span><h2>{dayLabel(selected)}</h2><small>{selectedAppointments.filter(a=>a.status!=="cancelled").length} ραντεβού</small></div><div className="panel-content">{selectedAppointments.length?selectedAppointments.map(a=><AppointmentRow key={a.id} appointment={a} client={clientsById.get(a.clientId)} edit={()=>onEdit(a)}/>):<div className="empty"><span className="empty-icon"><Sparkles/></span><h3>Η ημέρα είναι διαθέσιμη</h3><p>Δεν έχεις κλείσει ακόμη κάποιο ραντεβού για αυτή την ημερομηνία.</p></div>}</div><div className="panel-footer"><button className="secondary" onClick={()=>onNew(selected)}><CalendarPlus/> Ραντεβού σε αυτή την ημέρα</button></div></section>
  </div>
  <div className="section-header"><h2>Επόμενα ραντεβού</h2><small>{appointments.filter(a=>status(a)==="scheduled").length} προγραμματισμένα</small></div>
  <div className="upcoming-groups">{upcomingGroups.length?upcomingGroups.map(([date,list])=><section className="card upcoming-group" key={date}><h3>{dayLabel(date)}</h3>{list?.map(a=><AppointmentRow key={a.id} appointment={a} client={clientsById.get(a.clientId)} edit={()=>onEdit(a)}/>)}</section>):<section className="card upcoming-group upcoming-empty"><div className="empty"><span className="empty-icon"><CalendarDays/></span><h3>Δεν υπάρχουν επόμενα ραντεβού</h3><p>Πάτησε «Νέο Ραντεβού» για να ξεκινήσεις το πρόγραμμά σου.</p></div></section>}</div></>;
}

function ClientsView({clients,appointments,search,setSearch,onHistory}:{clients:Client[];appointments:Appointment[];search:string;setSearch:(s:string)=>void;onHistory:(c:Client)=>void}) {
  const filtered=clients.filter(c=>(c.name+" "+c.phone).toLocaleLowerCase("el").includes(search.toLocaleLowerCase("el"))).sort((a,b)=>a.name.localeCompare(b.name,"el"));
  return <><label className="search"><Search/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Αναζήτηση με όνομα ή τηλέφωνο" aria-label="Αναζήτηση πελάτισσας"/></label>{filtered.length?<div className="client-grid">{filtered.map(c=>{const history=appointments.filter(a=>a.clientId===c.id);return <button className="card client-card" key={c.id} onClick={()=>onHistory(c)}><span className="avatar">{c.name.slice(0,1).toUpperCase()}</span><span><strong>{c.name}</strong><p>{c.phone}</p></span><span className="client-meta muted">{history.length} ραντεβού</span></button>})}</div>:<div className="card empty"><span className="empty-icon"><UserRound/></span><h3>{search?"Δεν βρέθηκε πελάτισσα":"Το πελατολόγιο είναι άδειο"}</h3><p>{search?"Δοκίμασε διαφορετικό όνομα ή τηλέφωνο.":"Οι πελάτισσες προστίθενται αυτόματα με το πρώτο τους ραντεβού."}</p></div>}</>;
}

function StatsView({data}:{data:PlannerData}) {
  const completed=data.appointments.filter(a=>status(a)==="completed");const scheduled=data.appointments.filter(a=>status(a)==="scheduled");const revenue=completed.reduce((sum,a)=>sum+a.amountCents,0);const counts=categories.map(category=>({category,count:completed.filter(a=>a.category===category).length}));const max=Math.max(1,...counts.map(c=>c.count));
  return <><div className="stats-grid"><section className="card stat featured"><p>Έσοδα από πραγματοποιημένα</p><strong>{money(revenue)}</strong></section><section className="card stat"><p>Πραγματοποιημένα</p><strong>{completed.length}</strong></section><section className="card stat"><p>Επόμενα ραντεβού</p><strong>{scheduled.length}</strong></section></div><section className="card breakdown"><h2>Υπηρεσίες</h2><p className="muted">Πραγματοποιημένα ραντεβού ανά κατηγορία</p>{counts.map(item=><div className="bar-row" key={item.category}><span>{item.category}</span><div className="bar-track"><div style={{width:`${item.count/max*100}%`}}/></div><strong>{item.count}</strong></div>)}</section></>;
}

function HistoryModal({client,appointments,onClose,onEdit}:{client:Client;appointments:Appointment[];onClose:()=>void;onEdit:(a:Appointment)=>void}) {
  const dialog=useRef<HTMLDivElement>(null);useEffect(()=>{dialog.current?.focus();},[]);const sorted=[...appointments].sort((a,b)=>start(b)-start(a));
  return <><div className="modal-overlay" onMouseDown={onClose}/><div className="modal" role="dialog" aria-modal="true" aria-labelledby="history-title" tabIndex={-1} ref={dialog}><div className="modal-heading"><div><h2 id="history-title">{client.name}</h2><p className="muted">{client.phone}</p></div><button className="icon-button" onClick={onClose} aria-label="Κλείσιμο"><X/></button></div><div className="history-summary"><span>{appointments.length} ραντεβού</span><span>{appointments.filter(a=>status(a)==="completed").length} πραγματοποιημένα</span><span>{money(appointments.filter(a=>status(a)==="completed").reduce((sum,a)=>sum+a.amountCents,0))}</span></div>{sorted.length?sorted.map(a=><AppointmentRow key={a.id} appointment={a} client={client} edit={()=>onEdit(a)}/>):<div className="empty">Δεν υπάρχει ιστορικό.</div>}</div></>;
}
