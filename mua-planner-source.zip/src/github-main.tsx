import React from "react";
import ReactDOM from "react-dom/client";
import Planner from "@/components/planner/Planner";
import "@/app/globals.css";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <Planner />
  </React.StrictMode>,
);
